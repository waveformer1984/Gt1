
// Phase 11 – MemoryDecay: Softens old memories to reduce clutter and improve learning efficiency

import java.util.*;

public class MemoryDecay {
    private Map<String, Integer> memoryWeights = new HashMap<>();

    public void reinforce(String event) {
        memoryWeights.put(event, memoryWeights.getOrDefault(event, 1) + 1);
    }

    public void decay() {
        for (String key : memoryWeights.keySet()) {
            memoryWeights.put(key, Math.max(0, memoryWeights.get(key) - 1));
        }
    }

    public List<String> getStrongMemories() {
        List<String> strong = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : memoryWeights.entrySet()) {
            if (entry.getValue() > 1) strong.add(entry.getKey());
        }
        return strong;
    }
}
