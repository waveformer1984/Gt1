# ballsdeepnit

🚀 AI-powered REPL & module system with milestones.

## Modules
- `hydi_repl/` – Core AI REPL (self-fixing, shell-aware)
- `forgefinder/` – Funding tools (placeholder)
- `survybot/` – Survey automation (placeholder)

## Milestone-Driven
See `/milestones/` for progress tracking.

> As we meet our milestones, modules will activate and fuse into Hydi’s command map.
