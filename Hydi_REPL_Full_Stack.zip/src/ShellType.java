
public enum ShellType {
    CMD, POWERSHELL, GIT_BASH, BASH, UNKNOWN
}
