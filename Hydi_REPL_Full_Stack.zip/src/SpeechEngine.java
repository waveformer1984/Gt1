
public class SpeechEngine {
    public void speak(String text) {
        System.out.println("🗣️ " + text);
    }
}
