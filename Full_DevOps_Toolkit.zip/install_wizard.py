import os
import subprocess
from pathlib import Path

print("🚀 Welcome to the HydroCradle DevOps Toolkit Installer (Cross-Platform Edition)")
print("---------------------------------------------------")

jira_url = input("🌐 Enter your Jira URL (e.g., https://yourdomain.atlassian.net): ").strip()
jira_user = input("👤 Enter your Jira email: ").strip()
jira_token = input("🔑 Enter your Jira API token: ").strip()
jira_project = input("📂 Enter your Jira project key (e.g., PROJ): ").strip()

env_path = Path("config/.env")
env_path.parent.mkdir(parents=True, exist_ok=True)

with open(env_path, "w") as f:
    f.write(f"JIRA_URL={jira_url}\n")
    f.write(f"JIRA_USER={jira_user}\n")
    f.write(f"JIRA_TOKEN={jira_token}\n")
    f.write(f"JIRA_PROJECT={jira_project}\n")

print(f"✅ .env config created at {env_path}")

print("📦 Setting up virtual environment and installing dependencies...")
subprocess.run(["python", "-m", "venv", "venv"])
if os.name == 'nt':
    activate_cmd = ".\\venv\\Scripts\\activate && pip install -r requirements.txt"
else:
    activate_cmd = "source ./venv/bin/activate && pip install -r requirements.txt"
subprocess.run(activate_cmd, shell=True)

print("🧪 Running test issue creation...")
subprocess.run("python src/create_issue.py", shell=True)

print("🎉 Setup complete! Ready to sync with Jira.")
