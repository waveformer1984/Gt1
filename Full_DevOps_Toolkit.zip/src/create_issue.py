from jira import JIRA
import os
from dotenv import load_dotenv

load_dotenv(dotenv_path='config/.env')

def create_issue():
    jira = JIRA(server=os.getenv('JIRA_URL'),
                basic_auth=(os.getenv('JIRA_USER'), os.getenv('JIRA_TOKEN')))
    issue_dict = {
        'project': {'key': os.getenv('JIRA_PROJECT')},
        'summary': 'Auto-created by full DevOps toolkit',
        'description': 'This was generated using the full wizard pipeline system.',
        'issuetype': {'name': 'Task'},
    }
    issue = jira.create_issue(fields=issue_dict)
    print(f"Issue successfully created: {issue.key}")

if __name__ == '__main__':
    create_issue()
