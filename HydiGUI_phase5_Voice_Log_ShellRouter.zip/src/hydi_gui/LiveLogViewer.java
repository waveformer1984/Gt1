package hydi_gui;

import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;

public class LiveLogViewer extends VBox {
    private TextArea logArea;

    public LiveLogViewer() {
        logArea = new TextArea();
        logArea.setEditable(false);
        logArea.setFont(Font.font("Monospaced", 12));
        this.getChildren().addAll(new Label("Live Execution Log:"), logArea);
    }

    public void append(String line) {
        logArea.appendText(line + "\n");
    }
}
