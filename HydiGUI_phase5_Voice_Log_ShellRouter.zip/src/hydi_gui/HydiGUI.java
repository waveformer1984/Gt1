package hydi_gui;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.ArrayList;

public class HydiGUI extends Application {

    LiveLogViewer logViewer;

    @Override
    public void start(Stage stage) {
        CommandChain cc = new CommandChain();
        cc.addCommand("echo Hello from Hydi");
        cc.addCommand("java -version");

        CommandChainEditor editor = new CommandChainEditor(cc.commands);
        logViewer = new LiveLogViewer();

        javafx.scene.control.Button voiceBtn = new javafx.scene.control.Button("🎙️ Add via Voice");
        voiceBtn.setOnAction(e -> {
            String cmd = VoiceCommandInput.listenForCommand();
            cc.addCommand(cmd);
            editor.getChildren().clear();
            editor.getChildren().addAll(new javafx.scene.control.Label("Command Chain Editor"), editor.listContainer);
        });

        javafx.scene.control.Button runBtn = new javafx.scene.control.Button("▶️ Run");
        runBtn.setOnAction(e -> {
            for (String cmd : cc.commands) {
                String result = SystemLauncher.runCommand(cmd);
                logViewer.append("> " + cmd);
                logViewer.append(result);
            }
        });

        VBox root = new VBox(10, editor, voiceBtn, runBtn, logViewer);
        Scene scene = new Scene(root, 600, 500);
        stage.setTitle("Hydi Phase 5");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
