package hydi_gui;

import javax.sound.sampled.*;
import java.util.Scanner;

public class VoiceCommandInput {
    public static String listenForCommand() {
        System.out.println("[VOICE] Listening simulated — type your command:");
        Scanner sc = new Scanner(System.in);
        return sc.nextLine(); // Simulated voice input
    }
}
