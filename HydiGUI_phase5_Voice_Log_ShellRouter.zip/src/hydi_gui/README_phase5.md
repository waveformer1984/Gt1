# Phase 5 — Voice Input, Live Logs, and Auto Shell Launcher

## 🚀 New Components

- 🎙️ `VoiceCommandInput` — simulates voice command input (CLI-driven for now)
- 🧪 `LiveLogViewer` — shows command output in real time
- 🖥️ `SystemLauncher` — detects OS and routes shell commands (Bash, PowerShell, ZSH)

## 🧪 Usage

```bash
javac -cp gson.jar;PATH_TO_JAVAFX\lib\* src/hydi_gui/*.java -d out
java -cp gson.jar;PATH_TO_JAVAFX\lib\*;out hydi_gui.HydiGUI
```

> Next: Context awareness, branching logic, error loop retry!
