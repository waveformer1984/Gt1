package hydi_gui;

import java.io.*;
import java.util.*;

public class SystemLauncher {
    public static String getDefaultShell() {
        String os = System.getProperty("os.name").toLowerCase();
        if (os.contains("win")) return "powershell.exe";
        if (os.contains("mac")) return "/bin/zsh";
        return "/bin/bash";
    }

    public static String runCommand(String command) {
        try {
            String shell = getDefaultShell();
            ProcessBuilder pb = new ProcessBuilder(shell, "-c", command);
            pb.redirectErrorStream(true);
            Process p = pb.start();

            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }

            p.waitFor();
            return output.toString();
        } catch (Exception e) {
            return "Error running command: " + e.getMessage();
        }
    }
}
