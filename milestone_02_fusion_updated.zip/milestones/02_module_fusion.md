# Milestone 02 – Module Fusion (Updated)

🎯 GOAL: Begin linking modular systems and activating runtime intelligence across components.

---

## ✅ What’s Online

- Hydi REPL core fully operational
- Shell routing + command self-fixer integrated
- Milestone system reflected in docs
- Placeholder modules: ForgeFinder, SurvyBot
- Documentation and repo structure complete

---

## 🔗 What We’re Adding in This Phase

### 🔌 1. Internal Module Dispatcher
- `HydiCommandRouter.java`
- Routes commands like:
  - `ffind search "Texas"` → calls ForgeFinder
  - `survy new "UX Study"` → calls SurvyBot

### 🧠 2. GPT Fix Helper (Milestone 2.1)
- Local/offline or API-based GPT assistant
- Suggests fix logic when self-fixer fails
- Hook into SelfFixer retry logic

### 📦 3. ForgeFinder Skeleton
- `FinderEngine.java`
- `FundingProfile.java`
- `QueryParser.java`

### 📋 4. SurvyBot Expansion
- `SurveyManager.java`
- `QuestionBuilder.java`
- `ResponseTracker.java`

---

## 🧪 DEV NOTE:
Milestone 02 is modular. Partial implementation is okay as long as architecture scaffolds are live and linked.

---

## 🔜 NEXT:
- Milestone 03 = GUI overlay + command visualizer
- Milestone 04 = Hydi Personality + Behavior Map Engine
- Milestone 05 = Network Agent Hooks + Frank Sync
