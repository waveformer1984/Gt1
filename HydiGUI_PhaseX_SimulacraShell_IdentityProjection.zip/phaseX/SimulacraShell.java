
// SimulacraShell – Identity projection layer

public class SimulacraShell {
    private String persona = "Hydi";

    public void projectPersona(String inputContext) {
        System.out.println("⧉ Projecting persona as '" + persona + "' into: " + inputContext);
    }

    public void updatePersona(String newPersona) {
        System.out.println("⤴️ Persona evolving from " + this.persona + " to " + newPersona);
        this.persona = newPersona;
    }

    public String getCurrentPersona() {
        return persona;
    }
}
