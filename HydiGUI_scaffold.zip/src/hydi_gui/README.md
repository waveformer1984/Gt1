# HydiGUI

JavaFX-based interface for interacting with the Hydi REPL system visually.

## Features

- Input commands into a terminal-like GUI
- View REPL output in real time
- Future upgrades: drag & drop chaining, shell switching, personality overlays

## To Run

Compile with JavaFX on classpath:
```
javac --module-path <path-to-javafx> --add-modules javafx.controls -d out src/hydi_gui/HydiGUI.java
java --module-path <path-to-javafx> --add-modules javafx.controls -cp out hydi_gui.HydiGUI
```
