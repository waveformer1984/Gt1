package hydi_gui;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import hydi_repl.CommandREPL;

public class HydiGUI extends Application {

    private TextArea commandInput;
    private TextArea outputArea;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Hydi REPL GUI");

        commandInput = new TextArea();
        commandInput.setPromptText("Enter your command...");

        outputArea = new TextArea();
        outputArea.setEditable(false);

        Button runButton = new Button("Run");
        runButton.setOnAction(e -> runCommand());

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(15));
        layout.getChildren().addAll(new Label("Hydi REPL Command Input:"), commandInput, runButton, new Label("Output:"), outputArea);

        Scene scene = new Scene(layout, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void runCommand() {
        String command = commandInput.getText();
        outputArea.appendText("> " + command + "\n");
        String result = CommandREPL.execute(command);
        outputArea.appendText(result + "\n");
    }

    public static void main(String[] args) {
        launch(args);
    }
}
