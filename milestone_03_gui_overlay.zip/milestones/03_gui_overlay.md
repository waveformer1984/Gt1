# Milestone 03 – GUI Overlay + Command Visualizer

🎯 GOAL: Provide a visual interface for Hydi REPL and modular task interaction.

---

## ✅ Design Goals

- Clean, modern UI layer over Hydi
- Drag-and-drop command chaining (visual sequences)
- Real-time logs from REPL execution
- User toggles for:
  - Self-fix retry loop
  - Language output
  - Module triggers (e.g. ForgeFinder, SurvyBot)

---

## 📦 Initial Components

### 1. GUI Shell (JavaFX or React-based)
- `HydiGUI.java` or `gui/HydiDashboard.jsx`
- Displays:
  - Active shell and interpreter
  - Command log
  - Output feedback
  - Status bar (language, shell, REPL mode)

### 2. Command Visualizer
- Flowchart-style interface
- Connect commands with arrows
- Store/reload `.sequence` files

### 3. Execution Console
- Live command output
- Manual command input + button-based commands
- Toggle logs vs. visual

---

## 🧠 Advanced (Future)
- Contextual help on hover (command descriptions)
- Autocomplete with module mapping
- Hydi Mood Indicator (tied to task success/failure)
- Voice-to-command execution pane

---

## 🧪 DEV NOTE:
GUI can be built in phases:
- Terminal overlay first (JavaFX or Swing)
- Then embed visualizer
- Then add real-time command inspector

---

## 🔜 NEXT:
- Milestone 04 = Hydi Personality + Behavior Engine
- Milestone 05 = Frank Sync + Remote Node Coordination
