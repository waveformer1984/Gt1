# Frank Cortex for PM Bot

Extracted and ready to launch inside HYDI_System.
