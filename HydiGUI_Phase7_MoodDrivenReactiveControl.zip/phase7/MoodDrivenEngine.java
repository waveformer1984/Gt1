
// MoodDrivenEngine: Modifies system responses, visual feedback, and REPL behavior based on Hydi's 'mood'

public class MoodDrivenEngine {
    enum Mood { PRODUCTIVE, FRUSTRATED, IDLE, CURIOUS, CHAOTIC }

    private Mood currentMood = Mood.PRODUCTIVE;

    public void updateMood(Mood newMood) {
        this.currentMood = newMood;
        // Trigger internal tone/style shifts here
    }

    public Mood getCurrentMood() {
        return this.currentMood;
    }

    public String getResponseModifier() {
        switch (currentMood) {
            case PRODUCTIVE: return "fast_mode";
            case FRUSTRATED: return "retry_aggressive";
            case IDLE: return "suggest_experiment";
            case CURIOUS: return "explore_options";
            case CHAOTIC: return "unlock_all_the_things";
            default: return "default";
        }
    }
}
