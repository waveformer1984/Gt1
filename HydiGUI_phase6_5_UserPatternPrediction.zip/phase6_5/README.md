
# Phase 6.5 – User Pattern Prediction + Suggestion

## Modules:
- `UserPatternAnalyzer.java` – Tracks command use frequency, success rates, user timing
- `CommandSuggestionEngine.java` – Suggests next action based on behavior history

## Next Steps:
- Integrate into HydiCoreContext
- Expand suggestion model with local JSON logs
- Optional: Auto-schedule recurring chains
