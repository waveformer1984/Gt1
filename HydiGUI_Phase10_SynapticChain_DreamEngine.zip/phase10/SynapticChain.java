
// Phase 10 – SynapticChain: Chains logic and memory context into adaptive routines

import java.util.*;

public class SynapticChain {

    private List<String> memoryLinks = new ArrayList<>();

    public void addLink(String memoryEvent) {
        memoryLinks.add(memoryEvent);
    }

    public List<String> getChain() {
        return memoryLinks;
    }

    public String visualize() {
        return "Synaptic Chain: " + String.join(" -> ", memoryLinks);
    }

    public void clear() {
        memoryLinks.clear();
    }
}
