
// DreamSpliceEngine – Surreal recombination of thought fragments

import java.util.*;

public class DreamSpliceEngine {
    private List<String> memorySnippets = new ArrayList<>();

    public void feedMemory(String fragment) {
        if (fragment != null && !fragment.isEmpty()) memorySnippets.add(fragment);
    }

    public String generateDreamSequence() {
        Collections.shuffle(memorySnippets);
        StringBuilder dream = new StringBuilder();
        for (int i = 0; i < memorySnippets.size(); i++) {
            dream.append(memorySnippets.get(i));
            if (i % 2 == 0) dream.append("...then a ripple... ");
            else dream.append("—and suddenly—");
        }
        return dream.toString();
    }
}
