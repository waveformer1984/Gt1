
// MemoryDistortionFilter – Skews memory fragments to simulate imperfect recall

import java.util.Random;

public class MemoryDistortionFilter {
    private static final String[] hallucinations = {
        "a flicker of red light", "whispers from the left", "laughter with no source",
        "a face that wasn't", "static under the skin"
    };

    public static String distort(String input) {
        Random rand = new Random();
        int glitch = rand.nextInt(hallucinations.length);
        return hallucinations[glitch] + " :: " + input.replaceAll("[aeiou]", "*");
    }
}
