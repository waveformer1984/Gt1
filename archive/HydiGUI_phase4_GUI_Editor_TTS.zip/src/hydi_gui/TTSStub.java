package hydi_gui;

public class TTSStub {
    public static void speak(String text) {
        System.out.println("[TTS] " + text);
    }
}
