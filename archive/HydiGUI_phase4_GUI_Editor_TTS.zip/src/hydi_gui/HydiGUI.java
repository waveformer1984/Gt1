package hydi_gui;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.util.ArrayList;

public class HydiGUI extends Application {

    @Override
    public void start(Stage stage) {
        CommandChain cc = new CommandChain();
        cc.addCommand("echo Hello from Hydi");
        cc.addCommand("java -version");

        CommandChainEditor editor = new CommandChainEditor(cc.commands);

        Scene scene = new Scene(editor, 500, 400);
        stage.setTitle("HydiGUI: Phase 4");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
