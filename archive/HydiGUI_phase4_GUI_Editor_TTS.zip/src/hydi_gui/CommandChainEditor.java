package hydi_gui;

import java.util.List;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.geometry.Insets;

public class CommandChainEditor extends VBox {
    private List<String> commands;
    private VBox listContainer;

    public CommandChainEditor(List<String> commands) {
        this.commands = commands;
        this.setSpacing(10);
        this.setPadding(new Insets(10));

        Label title = new Label("Command Chain Editor");
        listContainer = new VBox(5);
        refresh();

        Button addBtn = new Button("Add Command");
        addBtn.setOnAction(e -> {
            TextField tf = new TextField("your-command-here");
            tf.setOnAction(evt -> updateCommands());
            listContainer.getChildren().add(tf);
        });

        this.getChildren().addAll(title, listContainer, addBtn);
    }

    private void refresh() {
        listContainer.getChildren().clear();
        for (String cmd : commands) {
            TextField tf = new TextField(cmd);
            tf.setOnAction(e -> updateCommands());
            listContainer.getChildren().add(tf);
        }
    }

    private void updateCommands() {
        commands.clear();
        for (javafx.scene.Node node : listContainer.getChildren()) {
            if (node instanceof TextField) {
                commands.add(((TextField) node).getText());
            }
        }
    }
}
