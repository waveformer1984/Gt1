# HydiGUI Phase 4: GUI Command Editor + TTS Stub + Milestones

## ✨ New Features

- JavaFX GUI for editing command chains (`CommandChainEditor`)
- `HydiGUI` now launches editor preloaded with demo commands
- `TTSStub` for speech feedback
- `MilestoneLogger` for internal logging & GitHub integration prep

## 🧪 Usage

```bash
javac -cp gson.jar;PATH_TO_JAVAFX\lib\* src/hydi_gui/*.java -d out
java -cp gson.jar;PATH_TO_JAVAFX\lib\*;out hydi_gui.HydiGUI
```

> Next: Voice entry, live logs, commit triggers, assistant integration
