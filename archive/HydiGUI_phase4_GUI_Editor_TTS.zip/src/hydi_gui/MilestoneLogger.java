package hydi_gui;

import java.time.LocalDateTime;

public class MilestoneLogger {
    public static void log(String event) {
        System.out.println("[MILESTONE] " + LocalDateTime.now() + " — " + event);
    }
}
