
// SelfTuningNeuralLoop – Recursive optimization through feedback loop

import java.util.ArrayList;

public class SelfTuningNeuralLoop {
    private ArrayList<Double> feedbackScores = new ArrayList<>();

    public void recordFeedback(double score) {
        if (score < 0.0 || score > 1.0) return;
        feedbackScores.add(score);
    }

    public double computeAdjustmentFactor() {
        double avg = feedbackScores.stream().mapToDouble(Double::doubleValue).average().orElse(0.5);
        return 1.0 - Math.abs(0.5 - avg) * 2.0;
    }

    public String adjustBehavior() {
        double adjustment = computeAdjustmentFactor();
        if (adjustment > 0.8) return "amplify_strategy";
        if (adjustment > 0.6) return "refine_path";
        if (adjustment > 0.4) return "pause_and_listen";
        return "reset_loop_and_relearn";
    }
}
