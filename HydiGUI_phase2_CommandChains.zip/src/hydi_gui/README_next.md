# HydiGUI Phase 2: Command Chain Execution

## Additions:
- `ShellDispatcher.java` — Smart shell execution handler
- `ChainRunner.java` — Executes sequences of commands
- [Planned] Self-healing retry logic on failure

## Compile:
```
javac --module-path <path-to-javafx> --add-modules javafx.controls -d out src/hydi_gui/*.java
java --module-path <path-to-javafx> --add-modules javafx.controls -cp out hydi_gui.HydiGUI
```
