package hydi_gui;

import java.io.*;

public class ShellDispatcher {

    public static String dispatch(String shell, String command) {
        try {
            ProcessBuilder builder;
            if (shell.equals("powershell")) {
                builder = new ProcessBuilder("powershell.exe", "-Command", command);
            } else if (shell.equals("cmd")) {
                builder = new ProcessBuilder("cmd.exe", "/c", command);
            } else if (shell.equals("bash")) {
                builder = new ProcessBuilder("bash", "-c", command);
            } else {
                return "[ERROR] Unknown shell: " + shell;
            }

            builder.redirectErrorStream(true);
            Process process = builder.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }

            process.waitFor();
            return output.toString();
        } catch (Exception e) {
            return "[ERROR] " + e.getMessage();
        }
    }
}
