package hydi_gui;

import java.util.List;

public class ChainRunner {

    public static void run(List<String> commands) {
        String shell = CommandRouter.detectShell();
        for (String cmd : commands) {
            String result = ShellDispatcher.dispatch(shell, cmd);
            System.out.println(">> " + cmd + "\n" + result);
            if (result.contains("[ERROR]")) {
                System.out.println("[AUTOFIX] Attempting to fix and re-run...");
                // Insert self-heal logic or reattempt loop here
                break;
            }
        }
    }
}
