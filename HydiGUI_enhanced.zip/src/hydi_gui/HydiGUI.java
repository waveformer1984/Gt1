package hydi_gui;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import hydi_repl.CommandREPL;

public class HydiGUI extends Application {

    private TextArea commandInput;
    private TextArea outputArea;
    private Label moodLabel;
    private boolean voiceEnabled = false;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Hydi REPL GUI");

        commandInput = new TextArea();
        commandInput.setPromptText("Enter your command...");

        outputArea = new TextArea();
        outputArea.setEditable(false);

        moodLabel = new Label("Mood: Neutral");

        Button runButton = new Button("Run");
        runButton.setOnAction(e -> runCommand());

        ToggleButton voiceToggle = new ToggleButton("Voice: Off");
        voiceToggle.setOnAction(e -> {
            voiceEnabled = !voiceEnabled;
            voiceToggle.setText(voiceEnabled ? "Voice: On" : "Voice: Off");
        });

        Label dragStub = new Label("🔧 Drag-and-drop chaining (coming soon)");

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(15));
        layout.getChildren().addAll(
            new Label("Hydi REPL Command Input:"), commandInput,
            runButton, voiceToggle, moodLabel,
            new Label("Output:"), outputArea,
            dragStub
        );

        Scene scene = new Scene(layout, 900, 650);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void runCommand() {
        String command = commandInput.getText();
        outputArea.appendText("> " + command + "\n");
        String result = CommandREPL.execute(command);
        outputArea.appendText(result + "\n");

        updateMood(result);
    }

    private void updateMood(String response) {
        if (response.contains("error") || response.contains("fail")) {
            moodLabel.setText("Mood: Frustrated 😠");
        } else if (response.contains("success") || response.contains("done")) {
            moodLabel.setText("Mood: Happy 😄");
        } else {
            moodLabel.setText("Mood: Neutral 😐");
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
