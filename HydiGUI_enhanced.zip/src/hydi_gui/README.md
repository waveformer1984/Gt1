# HydiGUI

JavaFX-based interface for Hydi REPL.

## Features

- Real-time command execution via GUI
- Mood indicator based on REPL output
- Voice toggle button (stub for TTS integration)
- Drag-and-drop command chaining placeholder

## Run Instructions

Compile with JavaFX:
```
javac --module-path <path-to-javafx> --add-modules javafx.controls -d out src/hydi_gui/HydiGUI.java
java --module-path <path-to-javafx> --add-modules javafx.controls -cp out hydi_gui.HydiGUI
```
