
# Hydi Core (v1.0)

🔹 **Core Modules Enabled**
- hydi_repl
- shell_router
- self_fix
- tts_translate
- command_scheduler
- context_memory

🔹 **Experimental Modules (Disabled by Default)**
Located in `/experiments/` folder.
Toggle `.toggle` files to `true` to activate:
- dreamsplice
- emotion_trigger
- auto_divergence
- memory_distortion
- phantom_echoes
