# Frank Bot Standalone

Desktop AI System for HYDI, RAID, and ProtoForge Integration

## Quick Start

```bash
cd frank_standalone
./frank_launcher.sh
```

## Commands

- `./frank_launcher.sh start` - Start Frank Bot
- `./frank_launcher.sh stop` - Stop Frank Bot  
- `./frank_launcher.sh status` - Check status
- `./frank_launcher.sh logs` - View logs
- `./frank_launcher.sh config` - Edit configuration

## Web Interface

Once started, access Frank at: http://localhost:3001

## Configuration

Edit `config.json` to customize:
- Port settings
- Capability toggles
- Sync intervals
- Logging preferences

## System Requirements

- Node.js 18+
- 100MB disk space
- Network access for sync operations

## Integration

Frank automatically syncs with:
- HYDI Core System (30s intervals)
- RAID Riplet Core (60s intervals)  
- ProtoForge Divisions (120s intervals)

## Capabilities

1. **Lexicon Analysis** - Advanced semantic processing
2. **System Integration** - Multi-platform synchronization
3. **Workflow Automation** - Intelligent task orchestration
4. **Communication Hub** - Natural language processing
5. **System Monitor** - Real-time performance tracking

## API Endpoints

- `GET /status` - System status and metrics
- `POST /task` - Submit processing tasks
- `POST /sync` - Trigger sync operations

## Troubleshooting

- Check logs: `./frank_launcher.sh logs`
- Verify config: `./frank_launcher.sh config`
- Restart system: `./frank_launcher.sh restart`

Frank Bot operates independently on your desktop while maintaining secure connections to your primary systems.