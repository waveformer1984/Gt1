
// ThoughtGraph – Connects concepts, memories, and triggers into a navigable brain-map

import java.util.*;

public class ThoughtGraph {
    private Map<String, Set<String>> graph = new HashMap<>();

    public void addAssociation(String concept, String related) {
        graph.putIfAbsent(concept, new HashSet<>());
        graph.get(concept).add(related);
    }

    public Set<String> getAssociations(String concept) {
        return graph.getOrDefault(concept, new HashSet<>());
    }

    public void displayMap() {
        System.out.println("Hydi's ThoughtGraph:");
        for (var entry : graph.entrySet()) {
            System.out.println("⟶ " + entry.getKey() + " linked to " + entry.getValue());
        }
    }
}
