
// VisionLayer: Integrates real-time perception inputs and awareness triggers
// Not visual-vision yet – 'vision' as context-awareness

import java.util.HashSet;
import java.util.Set;

public class VisionLayer {

    private Set<String> activeContexts;

    public VisionLayer() {
        activeContexts = new HashSet<>();
    }

    public void perceive(String contextTag) {
        activeContexts.add(contextTag.toLowerCase());
    }

    public boolean isAwareOf(String contextTag) {
        return activeContexts.contains(contextTag.toLowerCase());
    }

    public void clearVision() {
        activeContexts.clear();
    }

    public String summarizeAwareness() {
        return "Current contexts: " + String.join(", ", activeContexts);
    }
}
