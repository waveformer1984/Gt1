package hydi_gui;

import java.util.List;

public class ChainRunner {

    public static void run(List<String> commands) {
        String shell = CommandRouter.detectShell();

        for (String cmd : commands) {
            int attempts = 0;
            String result;
            while (attempts < 3) {
                result = ShellDispatcher.dispatch(shell, cmd);
                System.out.println(">> " + cmd + "\n" + result);

                if (!result.contains("[ERROR]")) break;
                System.out.println("[AUTOFIX] Attempt " + (attempts + 1) + " failed. Retrying...");
                attempts++;
            }
            if (attempts >= 3) {
                System.out.println("[FAILED] Command failed after retries: " + cmd);
                break;
            }
        }
    }
}
