# HydiGUI Phase 3: Self-Healing + Command Persistence

## ✅ New Features

- `CommandChain.java` — Save/load .json files for command groups.
- `ChainRunner` — Now retries failed commands up to 3 times.
- JSON persistence using GSON.

## 🔧 Build & Run

Ensure GSON is on classpath:
https://github.com/google/gson

```bash
javac -cp gson.jar src/hydi_gui/*.java -d out
java -cp gson.jar:out hydi_gui.HydiGUI
```
