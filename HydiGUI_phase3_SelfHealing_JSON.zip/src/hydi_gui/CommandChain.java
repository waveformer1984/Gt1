package hydi_gui;

import java.io.*;
import java.util.*;
import com.google.gson.*;

public class CommandChain {
    public List<String> commands;

    public CommandChain() {
        commands = new ArrayList<>();
    }

    public static CommandChain loadFromFile(String path) throws IOException {
        Gson gson = new Gson();
        try (Reader reader = new FileReader(path)) {
            return gson.fromJson(reader, CommandChain.class);
        }
    }

    public void saveToFile(String path) throws IOException {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try (Writer writer = new FileWriter(path)) {
            gson.toJson(this, writer);
        }
    }

    public void addCommand(String cmd) {
        commands.add(cmd);
    }
}
