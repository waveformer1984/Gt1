# Milestone 02 – Module Fusion

🎯 Goals:
- Hydi can call ForgeFinder routines
- SurvyBot outputs routed to REPL or DB
- Full CLI command mapping
- Shared system memory

🤖 Long-Term:
- Milestone 03 = GUI overlay
- Milestone 04 = LLM-based agent
