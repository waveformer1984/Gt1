package hydi_gui;

public class TTSStub {
    public static void speak(String message) {
        System.out.println("[TTS] " + message); // Replace with real TTS later
    }
}
