# 🔄 Daily Sync + Ping Trigger (Frank Scheduler - Windows Task Scheduler Format)

## Schedule:
- Time: 9:00 AM daily

## Triggers:
- Run: `FrankSyncLauncher.bat`

## Optional Enhancements:
- Add retry if offline
- Log to GitHub actions summary or Notion

## Example CMD:
schtasks /create /tn "FrankDailySync" /tr "C:\HYDI_System\Bots_&_Automation\pm_bot\frank_split\FrankSyncLauncher.bat" /sc daily /st 09:00
