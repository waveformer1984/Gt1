# 🔧 Notion Database Template for Frank

## Database: `Frank_Tasks_and_Concepts`

| Property      | Type        | Description                            |
|---------------|-------------|----------------------------------------|
| Title         | Title       | Name of the task or concept            |
| Type          | Select      | Task / Concept / Reference / Archive   |
| Priority      | Select      | High / Medium / Low                    |
| Tags          | Multi-select | Planning, Design, Coding, Docs        |
| Due Date      | Date        | Deadline or preferred completion       |
| Status        | Select      | Not Started / In Progress / Done       |
| Mood Impact   | Number (1-10)| Mood influence tracking               |
| Notes         | Text        | Freeform thoughts or links             |

🔗 Connect via Notion API using your integration token + database ID.
