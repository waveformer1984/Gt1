# 🧠 Mood Input to Frank via Vent'or or Voice

## Option A: Manual Check-In
- Daily prompt via UI or voice asking:
  - "How are you feeling today?"
  - Store input as: ["mood", "energy", "focus"]

## Option B: Voice Input
- Capture voice using microphone
- Transcribe with Whisper or Google Speech API
- Extract emotion keywords with sentiment analysis
- Pass to: `optimize_schedule_by_mood(mood_dict)`

## Mood Scale Suggestions:
- mood: happy / tired / anxious / calm / focused / overwhelmed
- energy: high / low
- focus: sharp / scattered
